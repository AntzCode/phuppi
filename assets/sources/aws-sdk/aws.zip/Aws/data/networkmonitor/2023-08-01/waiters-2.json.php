<?php
// This file was auto-generated from sdk-root/src/data/networkmonitor/2023-08-01/waiters-2.json
return [ 'version' => 2, 'waiters' => [],];
