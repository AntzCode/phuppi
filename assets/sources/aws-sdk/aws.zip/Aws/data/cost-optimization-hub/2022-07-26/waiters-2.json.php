<?php
// This file was auto-generated from sdk-root/src/data/cost-optimization-hub/2022-07-26/waiters-2.json
return [ 'version' => 2, 'waiters' => [],];
