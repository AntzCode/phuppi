<?php
// This file was auto-generated from sdk-root/src/data/cost-optimization-hub/2022-07-26/paginators-1.json
return [ 'pagination' => [ 'ListEnrollmentStatuses' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'items', ], 'ListRecommendationSummaries' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'items', ], 'ListRecommendations' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'items', ], ],];
