<?php
// This file was auto-generated from sdk-root/src/data/managedblockchain-query/2023-05-04/waiters-2.json
return [ 'version' => 2, 'waiters' => [],];
