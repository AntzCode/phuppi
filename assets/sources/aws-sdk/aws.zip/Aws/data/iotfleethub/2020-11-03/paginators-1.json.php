<?php
// This file was auto-generated from sdk-root/src/data/iotfleethub/2020-11-03/paginators-1.json
return [ 'pagination' => [ 'ListApplications' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'result_key' => 'applicationSummaries', ], ],];
