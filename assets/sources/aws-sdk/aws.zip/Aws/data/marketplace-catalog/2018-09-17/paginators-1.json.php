<?php
// This file was auto-generated from sdk-root/src/data/marketplace-catalog/2018-09-17/paginators-1.json
return [ 'pagination' => [ 'ListChangeSets' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'ChangeSetSummaryList', ], 'ListEntities' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'EntitySummaryList', ], ],];
