<?php
// This file was auto-generated from sdk-root/src/data/cloudfront-keyvaluestore/2022-07-26/paginators-1.json
return [ 'pagination' => [ 'ListKeys' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'Items', ], ],];
